// Empty template. Populate using scripts/catalog-key.mjs and your local PEREK_API_KEY.
export const configuredPerekKey: string = "";
